export type Priority = 'URGENTE' | 'ALTA' | 'NORMAL';
export type StatusAtraso = 'NO PRAZO' | 'EM ATRASO' | 'CRÍTICO';
export type StatusPedido = 'SOLICITADO' | 'EM COTAÇÃO' | 'PEDIDO EMITIDO' | 'NF RECEBIDA' | 'CANCELADO';
export type StatusCotacao = 'PENDENTE' | 'AGUARDANDO AP.' | 'APROVADO' | 'REPROVADO';

export interface Installment {
  numero: number;
  vencimento: string;
  valor: number;
  paga: boolean;
}

export interface Order {
  id: string;
  solicitacaoNo: string;
  dataSolicitacao: string;
  pedidoNo?: string;
  fornecedor: string;
  nfNo?: string;
  vencimentoNF?: string;
  previsaoEntrega?: string;
  valor: number;
  parcelas: number;
  listaParcelas?: Installment[];
  prioridade: Priority;
  statusAtraso: StatusAtraso;
  status: StatusPedido;
  responsavel: string;
  observacoes: string;
  isArchived?: boolean;
}

export interface SupplierOffer {
  id: string;
  nome: string;
  marca?: string;
  valorUnit: number;
  total: number;
  difal?: number;
}

export interface QuotationItem {
  id: string;
  codigo?: string;
  partNumber?: string;
  descricao: string;
  unidade: string;
  quantidade: number;
  fornecedores: SupplierOffer[];
  menorValor?: number;
  vencedor?: string;
}

export interface QuotationMap {
  id: string;
  titulo: string;
  tagEquipamento?: string;
  prazoEntrega?: string;
  data: string;
  solicitante: string;
  departamento: string;
  status: StatusCotacao;
  itens: QuotationItem[];
  isArchived?: boolean;
}