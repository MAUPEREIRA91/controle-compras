
import { Order, QuotationMap } from './types';

export const INITIAL_ORDERS: Order[] = [
  {
    id: '1',
    solicitacaoNo: 'SL-001',
    dataSolicitacao: '2026-02-10',
    pedidoNo: '26466',
    fornecedor: 'RODOBENS',
    nfNo: '28665',
    vencimentoNF: '2026-03-12',
    previsaoEntrega: '2026-02-25',
    valor: 1708.00,
    parcelas: 1,
    prioridade: 'NORMAL',
    statusAtraso: 'NO PRAZO',
    status: 'NF RECEBIDA',
    responsavel: 'MAURICIO',
    observacoes: 'DESLOCAMENTO'
  }
];

export const INITIAL_QUOTATION: QuotationMap = {
  id: 'MAP-888222',
  titulo: 'NOVA COTAÇÃO',
  data: new Date().toISOString().split('T')[0],
  solicitante: 'MAURICIO',
  departamento: 'SUPRIMENTOS',
  status: 'PENDENTE',
  tagEquipamento: 'CB78',
  prazoEntrega: 'A COMBINAR',
  itens: [
    {
      id: 'i1',
      codigo: '001',
      descricao: 'FILTRO PSC145',
      unidade: 'UN',
      quantidade: 1,
      fornecedores: [
        { id: 's1', nome: 'JOAO', marca: 'ORIGINAL', valorUnit: 12.00, total: 12.00 },
        { id: 's2', nome: 'MARIA', marca: 'IMPORTADA', valorUnit: 144.00, total: 144.00 },
        { id: 's3', nome: 'PEDRO', marca: 'PARALELA', valorUnit: 44.00, total: 44.00 }
      ],
      menorValor: 12.00,
      vencedor: 'JOAO'
    }
  ]
};
